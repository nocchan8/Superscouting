export interface EventData {
  key: string;
  name: string;
  city: string;
  start_date: string;
  end_date: string;
  short_name: string;
  week: number;
}

